#include "Game.h"
#include "Util.h"

Game* Game::s_pInstance = 0;

glm::vec2 Game::getTargetPosition()
{
	return m_pTarget->getPosition();
}

SDL_Renderer * Game::getRenderer()
{
	return m_pRenderer;
}

glm::vec2 Game::getMousePosition()
{
	return m_mousePosition;
}

Game::Game()
{
}

Game::~Game()
{
}

void Game::createGameObjects()
{
	m_pShip = new ship();
	m_pTarget = new Target();
	m_pMenu = new Menu();
	m_pObstacle = new Obstacle();
}

bool Game::init(const char* title, int xpos, int ypos, int height, int width, bool fullscreen)
{
	int flags = 0;

	if (fullscreen)
	{
		flags = SDL_WINDOW_FULLSCREEN;
	}

	// initialize SDL
	if (SDL_Init(SDL_INIT_EVERYTHING) >= 0)
	{
		std::cout << "SDL Init success" << std::endl;

		// if succeeded create our window
		m_pWindow = SDL_CreateWindow(title, xpos, ypos, height, width, flags);

		// if window creation successful create our renderer
		if (m_pWindow != 0)
		{
			std::cout << "window creation success" << std::endl;
			m_pRenderer = SDL_CreateRenderer(m_pWindow, -1, 0);

			if (m_pRenderer != 0) // render init success
			{
				std::cout << "renderer creation success" << std::endl;
				SDL_SetRenderDrawColor(m_pRenderer, 255, 255, 255, 255);
			}
			else
			{
				std::cout << "renderer init failure" << std::endl;
				return false; // render int fail
			}

			
			createGameObjects();
		}
		else 
		{
			std::cout << "window init failure" << std::endl;
			return false; // window init fail
		}
	}
	else
	{
		std::cout << "SDL init failure" << std::endl;
		return false; //SDL could not intialize
	}

	std::cout << "init success" << std::endl;
	m_bRunning = true; // everything initialized successfully - start the main loop

	return true;
}

void Game::render()
{
	SDL_RenderClear(m_pRenderer); // clear the renderer to the draw colour

	if (m_pShip->getSteeringState() == MENU)
	{
		m_pMenu->draw();
	}
	else if (m_pShip->getSteeringState() == AVOID)
	{
		m_pTarget->draw();
		m_pShip->draw();
		m_pObstacle->draw();
	}
	else
	{
		m_pTarget->draw();
		m_pShip->draw();
	}

	if (m_debug)
	{
		if (m_pShip->getSteeringState() == AVOID)
		{
			Util::DrawRect(m_pObstacle->getPosition() - glm::vec2(m_pObstacle->getWidth() * 0.5, m_pObstacle->getHeight() * 0.5), m_pObstacle->getWidth(), m_pObstacle->getHeight());
		}
		Util::DrawCircle(m_pShip->getPosition(), m_pShip->getHeight() * 0.5);
		Util::DrawCircle(m_pTarget->getPosition(), m_pTarget->getHeight() * 0.5);

		Util::DrawLine(m_pShip->getPosition(), m_pShip->getPosition() + m_pShip->getCurrentDirection() * 100.0f);
	}
	
	SDL_RenderPresent(m_pRenderer); // draw to the screen
}

void Game::update()
{
	if (CollisionManager::lineAABBCheck(m_pShip, m_pObstacle) && m_pShip->getSteeringState() == AVOID) // Middle Feeler
	{
		std::cout << "Feeler collision with obstacle!" << std::endl;
		m_pShip->setRayCollision(true, 1);
	}
	else // Left Feeler
	{
		m_pShip->setFacingAngle(m_pShip->getCurrentHeading() - 45);
		m_pShip->m_changeDirection();
		if (CollisionManager::lineAABBCheck(m_pShip, m_pObstacle) && m_pShip->getSteeringState() == AVOID)
		{
			std::cout << "Left feeler collision with obstacle!" << std::endl;
			m_pShip->setFacingAngle(m_pShip->getCurrentHeading() + 45);
			m_pShip->m_changeDirection();
			m_pShip->setRayCollision(true, 0);
		}
		else // Right Feeler
		{
			m_pShip->setFacingAngle(m_pShip->getCurrentHeading() + 90);
			m_pShip->m_changeDirection();
			if (CollisionManager::lineAABBCheck(m_pShip, m_pObstacle) && m_pShip->getSteeringState() == AVOID)
			{
				std::cout << "Right feeler collision with obstacle!" << std::endl;
				m_pShip->setFacingAngle(m_pShip->getCurrentHeading() - 45);
				m_pShip->m_changeDirection();
				m_pShip->setRayCollision(true, 2);
			}
			else
			{
				m_pShip->setFacingAngle(m_pShip->getCurrentHeading() - 45);
				m_pShip->m_changeDirection();
			}
			
		}
	}
	

	
	m_pShip->update();
	m_pTarget->update();

	
}

void Game::clean()
{
	std::cout << "cleaning game" << std::endl;

	SDL_DestroyRenderer(m_pRenderer);
	SDL_DestroyWindow(m_pWindow);
	SDL_Quit();
}

void Game::handleEvents()
{
	SDL_Event event;
	if (SDL_PollEvent(&event))
	{
		switch (event.type)
		{
		case SDL_QUIT:
			m_bRunning = false;
			break;
		case SDL_MOUSEMOTION:
			m_mousePosition.x = event.motion.x;
			m_mousePosition.y = event.motion.y;
			break;
		case SDL_KEYDOWN:
			switch (event.key.keysym.sym) {
				case SDLK_ESCAPE:
					m_bRunning = false;
					break;
				/*case SDLK_w:
					m_pTarget->setVelocity(glm::vec2(m_pTarget->getVelocity().x, -1.0f));
					m_pShip->setTargetPosition(m_pTarget->getPosition());
					break;
				case SDLK_s:
					m_pTarget->setVelocity(glm::vec2(m_pTarget->getVelocity().x, 1.0f));
					m_pShip->setTargetPosition(m_pTarget->getPosition());
					break;
				case SDLK_a:
					m_pTarget->setVelocity(glm::vec2(-1.0f, m_pTarget->getVelocity().y));
					m_pShip->setTargetPosition(m_pTarget->getPosition());
					break;
				case SDLK_d:
					m_pTarget->setVelocity(glm::vec2(1.0f, m_pTarget->getVelocity().y));
					m_pShip->setTargetPosition(m_pTarget->getPosition());
					break;*/
				case SDLK_0:
					m_pShip->setSteeringState(MENU);
					break;
				case SDLK_1:
					m_pTarget->setPosition(glm::vec2(50.0f, 100.0f));
					m_pShip->setPosition(glm::vec2(550.0f, 700.0f));
					m_pShip->setCurrentDirection(glm::vec2(1.0f, -1.0f));
					m_pShip->setFacingAngle(315.0f);
					m_pShip->setTargetPosition(m_pTarget->getPosition());
					m_pShip->setSteeringState(SEEK);
					break;
				case SDLK_2:
					m_pShip->setSteeringState(ARRIVE);
					break;
				case SDLK_3:
					m_pTarget->setPosition(glm::vec2(50.0f, 200.0f));
					m_pShip->setPosition(glm::vec2(900.0f, 350.0f));
					m_pShip->setCurrentDirection(glm::vec2(-1.0f, 0.0f));
					m_pShip->setFacingAngle(180.0f);
					m_pShip->setTargetPosition(m_pTarget->getPosition());
					m_pShip->setSteeringState(AVOID);
					break;
				case SDLK_4:
					m_pShip->setSteeringState(FLEE);
					break;
				case SDLK_RIGHT:
					m_pShip->turnRight();
					break;
				case SDLK_LEFT:
					m_pShip->turnLeft();
					break;
				case SDLK_UP:
					m_pShip->setVelocity(m_pShip->getCurrentDirection());
					// std::cout << "Current direction is: (" << m_pShip->getCurrentDirection().x << ", " << m_pShip->getCurrentDirection().y << ")\n"; // Leaving this as a comment to reuse it for more testing
					m_pShip->m_move();
					break;
				case SDLK_BACKQUOTE:
					m_debug = !m_debug;
					break;

			}
			break;
		case SDL_KEYUP:
			switch (event.key.keysym.sym) {
				case SDLK_w:
					if (m_pTarget->getVelocity().y < 0.0f) {
						m_pTarget->setVelocity(glm::vec2(m_pTarget->getVelocity().x, 0.0f));
					}
					break;
				
				case SDLK_s:
					if (m_pTarget->getVelocity().y > 0.0f) {
						m_pTarget->setVelocity(glm::vec2(m_pTarget->getVelocity().x, 0.0f));
					}
					break;
				
				case SDLK_a:
					if (m_pTarget->getVelocity().x < 0.0f) {
						m_pTarget->setVelocity(glm::vec2(0.0f, m_pTarget->getVelocity().y));
					}
					break;
				case SDLK_d:
					if (m_pTarget->getVelocity().x > 0.0f) {
						m_pTarget->setVelocity(glm::vec2(0.0f, m_pTarget->getVelocity().y));
					}
					break;
				case SDLK_RIGHT:
					break;
				case SDLK_LEFT:
					break;
				case SDLK_UP:
					m_pShip->setVelocity(glm::vec2(0, 0));
					break;
			}
			
		default:
			break;
		}
	}
}