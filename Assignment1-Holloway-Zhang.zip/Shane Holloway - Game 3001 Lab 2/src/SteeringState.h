#pragma once
#ifndef __STEERING_STATE__
#define __STEERING_STATE__

enum SteeringState {
	IDLE,
	SEEK,
	ARRIVE,
	AVOID,
	FLEE,
	MENU,
	NUM_OF_STATES
};

#endif /* __STEERING_STATE__ */
