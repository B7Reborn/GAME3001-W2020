#pragma once
#ifndef __Ship__
#define __Ship__

#include "GameObject.h"
#include "TextureManager.h"
#include "SoundManager.h"

class ship :
	public GameObject
{
public:
	ship();
	~ship();

	// Inherited via GameObject
	void draw() override;

	void update() override;

	void clean() override;

	void turnRight();
	
	void turnLeft();
	
	void m_move();

	void m_changeDirection();

	// Getters
	float getMaxSpeed();
	float getTurnRate();
	float getCurrentHeading();
	glm::vec2 getCurrentDirection();
	glm::vec2 getTargetPosition();
	glm::vec2 getTargetDirection();
	float getAngleToTarget();
	// glm::vec2 getObstaclePosition();
	glm::vec2 getRayVector();
	bool getRayCollision(int selection);
	
	// Setters
	void setMaxSpeed(float newSpeed);
	void setTurnRate(float newTurnRate);
	void setFacingAngle(float newAngle);
	void setCurrentDirection(glm::vec2 newDirection);
	void setTargetPosition(glm::vec2 newTargetPosition);
	void setTargetDirection(glm::vec2 newTargetDirection);
	void setRayVector(glm::vec2 newVector);
	void setRayCollision(bool newCollision, int selection);
	
private:
	void m_reset();
	
	// Steering functions
	void m_checkSteeringState();
	void m_seek();
	void m_checkArrival();
	bool m_computeTurnDirection(); // Returns a true for left turn, false for right
	void m_arrive();
	void m_avoid();
	void m_flee();

	// Movement functions
	void m_checkBounds();
	glm::vec2 m_currentDirection;

	float m_currentHeading; // Current angle of ship

	// Speed variables
	float m_maxSpeed;
	float m_turnRate; // Angle in degrees ship can turn per frame

	// Target information
	glm::vec2 m_targetPosition;
	glm::vec2 m_targetDirection;
	void m_computeTargetDirection();
	float m_angleToTarget;
	void m_computeAngleToTarget(); // Moved the computing of the angle to the target to its own function for easy reuse

	// Obstacle information
	bool m_rayCollision[3] = { false, false, false }; // 0 = Left, 1 = Centre, 2 = Right
	// glm::vec2 m_obstaclePosition;
	glm::vec2 m_rayVector;
	
};


#endif /* defined (__Ship__) */

