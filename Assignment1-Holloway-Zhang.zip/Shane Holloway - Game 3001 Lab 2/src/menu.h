#pragma once
#ifndef __Menu__
#define __Menu__

#include "GameObject.h"
#include "TextureManager.h"
#include "SoundManager.h"

class Menu : public GameObject {
public:
	// Constructor / Destrutor
	Menu();
	~Menu();

	// Inherited via GameObject
	void draw() override;
	void update() override;
	void clean() override;
private:
};

#endif // defined(__Menu__)

