// Game 3001 - Assignment 1 - Completed by Shane Holloway & Hancong Zhang
// Goal: Complete the 4 AI steering behaviors as described in class and the assignment outline
//

#include "ship.h"
#include "Game.h"
#include "Util.h"
#include "GLM/gtx/rotate_vector.hpp"


ship::ship()
{
	TheTextureManager::Instance()->load("../Assets/textures/ship3.png",
		"ship", TheGame::Instance()->getRenderer());

	glm::vec2 size = TheTextureManager::Instance()->getTextureSize("ship");
	setWidth(size.x);
	setHeight(size.y);
	setPosition(glm::vec2(400.0f, 300.0f));
	setVelocity(glm::vec2(0.0f, 0.0f));
	setAcceleration(glm::vec2(0.0f, 0.0f));
	
	setIsColliding(false);
	setType(SHIP);
	setSteeringState(MENU);
	m_maxSpeed = 2.0f;
	m_turnRate = 3.0f;
	m_currentDirection = glm::vec2(1.0f, 0.0f); // Looking right (east)
	m_currentHeading = 0.0f;
	
}


ship::~ship()
{
}

void ship::draw()
{
	int xComponent = getPosition().x;
	int yComponent = getPosition().y;

	TheTextureManager::Instance()->draw("ship", xComponent, yComponent,
		TheGame::Instance()->getRenderer(), m_currentHeading, 255, true);
}

void ship::m_checkSteeringState()
{
	switch (getSteeringState())
	{
	case IDLE:
		break;
	case SEEK:
		m_seek();
		m_move();
		// m_checkBounds();
		// m_checkArrival();
		break;
	case ARRIVE:
		break;
	case AVOID:
		m_seek();
		m_avoid();
		m_move();
		break;
	case FLEE:
		break;
	}
}

void ship::update()
{
	m_checkSteeringState();
}

void ship::clean()
{
}

void ship::turnRight()
{
	m_currentHeading += m_turnRate;
	if (m_currentHeading >= 360)
	{
		m_currentHeading -= 360;
	}
	// std::cout << "Current Heading = " << getCurrentHeading() << std::endl; // Leaving this as a comment to reuse it for more testing
	m_changeDirection();
	m_computeTargetDirection();
	m_computeAngleToTarget();
}

void ship::turnLeft()
{
	m_currentHeading -= m_turnRate;
	if (m_currentHeading < 0)
	{
		m_currentHeading += 360;
	}
	// std::cout << "Current Heading = " << getCurrentHeading() << std::endl; // Leaving this as a comment to reuse it for more testing
	m_changeDirection();
	m_computeTargetDirection();
	m_computeAngleToTarget();
}

void ship::m_move()
{
	glm::vec2 newPosition = getPosition() + getVelocity() * getMaxSpeed();
	setPosition(newPosition);
	for (int i = 0; i < 3; i++)
	{
		setRayCollision(false, i);
	}
}

void ship::m_changeDirection()
{
	float x = cos(m_currentHeading * Util::Deg2Rad);
	float y = sin(m_currentHeading * Util::Deg2Rad);
	m_currentDirection = glm::vec2(x, y);
}

float ship::getMaxSpeed()
{
	return m_maxSpeed;
}

float ship::getTurnRate()
{
	return m_turnRate;
}

float ship::getCurrentHeading()
{
	return m_currentHeading;
}

glm::vec2 ship::getCurrentDirection()
{
	return m_currentDirection;
}

glm::vec2 ship::getTargetPosition()
{
	return m_targetPosition;
}

glm::vec2 ship::getTargetDirection()
{
	return m_targetDirection;
}

float ship::getAngleToTarget()
{
	return m_angleToTarget;
}

glm::vec2 ship::getRayVector()
{
	return m_rayVector;
}

bool ship::getRayCollision(int selection)
{
	if (selection < 3 && selection > -1)
	return m_rayCollision[selection];
}

void ship::setMaxSpeed(float newSpeed)
{
	m_maxSpeed = newSpeed;
}

void ship::setTurnRate(float newTurnRate)
{
	m_turnRate = newTurnRate;
}

void ship::setFacingAngle(float newAngle)
{
	m_currentHeading = newAngle;
}

void ship::setCurrentDirection(glm::vec2 newDirection)
{
	m_currentDirection = newDirection;
}

void ship::setTargetPosition(glm::vec2 newTargetPosition)
{
	m_targetPosition = newTargetPosition;
}

void ship::setTargetDirection(glm::vec2 newTargetDirection)
{
	m_targetDirection = newTargetDirection;
}

void ship::setRayVector(glm::vec2 newVector)
{
	m_rayVector = newVector;
}

void ship::setRayCollision(bool newCollision, int selection)
{
	m_rayCollision[selection] = newCollision;
}

void ship::m_checkBounds()
{

	if (getPosition().x > 800)
	{
		setPosition(glm::vec2(0.0f, getPosition().y));
	}

	if (getPosition().x < 0)
	{
		setPosition(glm::vec2(800.0f, getPosition().y));
	}

	if (getPosition().y > 600)
	{
		setPosition(glm::vec2(getPosition().x, 0.0f));
	}

	if (getPosition().y < 0)
	{
		setPosition(glm::vec2(getPosition().x, 600.0f));
	}

}

void ship::m_computeTargetDirection()
{
	setTargetDirection(Util::normalize(getTargetPosition() - getPosition())); // targetDirection has a unit vector length (1)
}

void ship::m_computeAngleToTarget()
{
	m_angleToTarget = Util::angle(getCurrentDirection(), getTargetDirection());
	// std::cout << "Target direction: " << m_angleToTarget << std::endl; // Leaving this as a comment to reuse it for more testing
}

void ship::m_reset()
{

}

void ship::m_seek()
{
	if (getPosition().y < 550 && getPosition().x < 800) // Ship is fully on-screen
	{
		if (!getRayCollision(0) || !getRayCollision(1) || !getRayCollision(2)) // Skips seek turn logic if avoid movement is needed
		{
			if (getAngleToTarget() < 5) // Almost facing the target
			{
				// Don't turn
			}
			else if (m_computeTurnDirection()) // Check if target is to left of currently faced direction
			{
				turnLeft();
			}
			else // If target is not to left of currently faced direction, must be to the right
			{
				turnRight();
			}
			// While the following 2 lines are in the turn functions, leaving them here allows the ship to turn properly if 1 is pressed before moving the target or turning
			m_computeTargetDirection();
			m_computeAngleToTarget();
		}
		
	}
	setVelocity(getCurrentDirection());
	
}

void ship::m_checkArrival()
{
	if (Util::distance(getPosition(), getTargetPosition()) <= 5.0f)
	{
		setSteeringState(IDLE);
	}
}

// Returns a true for left turn, false for right.
bool ship::m_computeTurnDirection()
{
	// Create a temporary variable for a slight change in the currentHeading angle.
	float tempHeading = m_currentHeading - m_turnRate;

	// Using the tempHeading variable, create a temporary direction variable.
	float x = cos(tempHeading * Util::Deg2Rad);
	float y = sin(tempHeading * Util::Deg2Rad);
	glm::vec2 tempDirection = glm::vec2(x, y);

	// Make a temporary angle to the target based on the temporary direction.
	float tempAngleToTarget = Util::angle(tempDirection, getTargetDirection());

	// If this statement is true, it is faster to turn left. Otherwise, it is faster to turn right.
	if (tempAngleToTarget < getAngleToTarget())
	{
		return true;
	}
	return false; // Resharper said an else was redundant, so I made it outside of the if statement.
}

void ship::m_arrive()
{
}

void ship::m_avoid()
{
	if (getRayCollision(0) || getRayCollision(1)) // For simplicity's sake make the center feeler also turn right
	{
		turnRight();
		turnRight();
		setVelocity(glm::vec2(0, 0));
		//setVelocity(glm::vec2(getVelocity().x / 2, getVelocity().y / 2));
	}
	else if (getRayCollision(2))
	{
		turnLeft();
		turnLeft();
		setVelocity(glm::vec2(0, 0));
		//setVelocity(glm::vec2(getVelocity().x / 2, getVelocity().y / 2));
	}
}

void ship::m_flee()
{
}
