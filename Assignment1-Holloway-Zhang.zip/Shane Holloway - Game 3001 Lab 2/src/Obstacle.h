#pragma once
#ifndef __Obstacle__
#define __Obstacle__

#include "GameObject.h"
#include "TextureManager.h"
#include "SoundManager.h"

class Obstacle : public GameObject {
public:
	// Constructor / Destrutor
	Obstacle();
	~Obstacle();

	// Inherited via GameObject
	void draw() override;
	void update() override;
	void clean() override;
private:
};

#endif // defined(__Obstacle__)

