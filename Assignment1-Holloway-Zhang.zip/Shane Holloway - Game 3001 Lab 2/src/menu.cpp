#include "menu.h"
#include "Game.h"

Menu::Menu()
{
	TheTextureManager::Instance()->load("../Assets/textures/Menu.png",
		"menu", TheGame::Instance()->getRenderer());

	glm::vec2 size = TheTextureManager::Instance()->getTextureSize("menu");
	setWidth(size.x);
	setHeight(size.y);
	setIsColliding(false);
	setType(GameObjectType::MAINMENU);
	setPosition(glm::vec2(0, 0));
	TheTextureManager::Instance()->setAlpha("menu", 128);

}

Menu::~Menu()
{
}

void Menu::draw()
{
	int xComponent = getPosition().x;
	int yComponent = getPosition().y;
	TheTextureManager::Instance()->draw("menu", xComponent, yComponent,
		TheGame::Instance()->getRenderer(), false);
}

void Menu::update()
{
}

void Menu::clean()
{
}

