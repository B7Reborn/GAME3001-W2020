#include "Obstacle.h"
#include "Game.h"

Obstacle::Obstacle()
{
	TheTextureManager::Instance()->load("../Assets/textures/Obstacle.png",
		"obstacle", TheGame::Instance()->getRenderer());

	glm::vec2 size = TheTextureManager::Instance()->getTextureSize("obstacle");
	setWidth(size.x);
	setHeight(size.y);
	setIsColliding(false);
	setType(OBSTACLE);
	setPosition(glm::vec2(150.0f, 250.0f));


}

Obstacle::~Obstacle()
{
}

void Obstacle::draw()
{
	int xComponent = getPosition().x;
	int yComponent = getPosition().y;
	TheTextureManager::Instance()->draw("obstacle", xComponent, yComponent,
		TheGame::Instance()->getRenderer(), true);
}

void Obstacle::update()
{
}

void Obstacle::clean()
{
}

